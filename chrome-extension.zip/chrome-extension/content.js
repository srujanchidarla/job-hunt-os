(() => {
  const SIDEBAR_ID = 'jobhuntos-iframe-root';
  const ORIGIN = 'chrome-extension://' + chrome.runtime.id;

  function getIframe() {
    return document.getElementById(SIDEBAR_ID);
  }

  function getPageText() {
    // Clone body, remove noise elements
    const clone = document.body.cloneNode(true);
    clone.querySelectorAll(
      'script,style,nav,header,footer,aside,[role="banner"],[role="navigation"],[role="complementary"]'
    ).forEach((el) => el.remove());
    return (clone.innerText || clone.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 6000);
  }

  function sendPageData(iframe) {
    const payload = {
      type: 'PAGE_DATA',
      url: window.location.href,
      rawText: getPageText(),
    };
    // Retry a few times until sidebar is ready
    let attempts = 0;
    const interval = setInterval(() => {
      iframe.contentWindow?.postMessage(payload, ORIGIN);
      attempts++;
      if (attempts >= 5) clearInterval(interval);
    }, 400);
  }

  function openSidebar() {
    let iframe = getIframe();

    if (iframe) {
      iframe.style.transform = 'translateX(0)';
      iframe.dataset.open = 'true';
      sendPageData(iframe);
      return;
    }

    // Create wrapper to avoid layout shifts
    const wrapper = document.createElement('div');
    wrapper.id = SIDEBAR_ID;
    Object.assign(wrapper.style, {
      position: 'fixed',
      top: '0',
      right: '0',
      width: '400px',
      height: '100vh',
      zIndex: '2147483647',
      border: 'none',
      boxShadow: '-8px 0 32px rgba(0,0,0,0.5)',
      transform: 'translateX(0)',
      transition: 'transform 0.3s cubic-bezier(0.4,0,0.2,1)',
    });

    iframe = document.createElement('iframe');
    iframe.src = chrome.runtime.getURL('sidebar.html');
    Object.assign(iframe.style, {
      width: '100%',
      height: '100%',
      border: 'none',
      display: 'block',
    });
    wrapper.dataset.open = 'true';
    wrapper.appendChild(iframe);
    document.body.appendChild(wrapper);

    iframe.onload = () => sendPageData(iframe);
  }

  function closeSidebar() {
    const wrapper = getIframe();
    if (wrapper) {
      wrapper.style.transform = 'translateX(100%)';
      wrapper.dataset.open = 'false';
    }
  }

  function toggleSidebar() {
    const wrapper = getIframe();
    if (wrapper?.dataset.open === 'true') {
      closeSidebar();
    } else {
      openSidebar();
    }
  }

  // Messages from sidebar iframe
  window.addEventListener('message', (event) => {
    if (!event.origin.startsWith('chrome-extension://')) return;
    if (event.data?.type === 'CLOSE_SIDEBAR') closeSidebar();
    if (event.data?.type === 'RETRY') {
      const wrapper = getIframe();
      if (wrapper) sendPageData(wrapper.querySelector('iframe'));
    }
  });

  // Message from background
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'TOGGLE_SIDEBAR') toggleSidebar();
  });
})();
