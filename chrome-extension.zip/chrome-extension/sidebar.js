(() => {
  const BACKEND = 'http://localhost:3000/api/analyze';

  // ── DOM refs ──
  const $ = (id) => document.getElementById(id);
  const loadingState  = $('loadingState');
  const errorState    = $('errorState');
  const resultState   = $('resultState');
  const notionBanner  = $('notionBanner');

  // ── State ──
  let pagePayload = null; // stored so retry can reuse it

  // ── Helpers ──
  function showOnly(el) {
    [loadingState, errorState, resultState].forEach((s) => s.classList.add('hidden'));
    el.classList.remove('hidden');
  }

  function copyText(text, btn, label = 'Copy') {
    navigator.clipboard.writeText(text).then(() => {
      btn.textContent = '✓ Copied!';
      btn.classList.add('copied');
      setTimeout(() => {
        btn.textContent = label;
        btn.classList.remove('copied');
      }, 2000);
    }).catch(() => {
      // Clipboard API failed silently — still show feedback
      btn.textContent = '✓ Copied!';
      btn.classList.add('copied');
      setTimeout(() => { btn.textContent = label; btn.classList.remove('copied'); }, 2000);
    });
  }

  function scoreColor(score) {
    if (score >= 80) return 'var(--green)';
    if (score >= 60) return 'var(--amber)';
    return 'var(--red)';
  }

  function animateRing(score) {
    const circumference = 163.4;
    const offset = circumference - (score / 100) * circumference;
    const fill = $('ringFill');
    fill.style.stroke = scoreColor(score);
    // Trigger animation after paint
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        fill.style.strokeDashoffset = offset;
      });
    });
  }

  // ── Render ──
  function render(data) {
    $('jobRole').textContent    = data.role    || 'Unknown Role';
    $('jobCompany').textContent = data.company || 'Unknown Company';
    $('scoreNum').textContent   = data.fitScore ?? '—';
    $('fitReasoning').textContent = data.fitReasoning || '';

    if (typeof data.fitScore === 'number') animateRing(data.fitScore);

    // Bullets
    const list = $('bulletsList');
    list.innerHTML = '';
    $('bulletsBadge').textContent = (data.resumeBullets || []).length;
    (data.resumeBullets || []).forEach((bullet) => {
      const li = document.createElement('li');
      li.className = 'bullet-item';

      const dot = document.createElement('div');
      dot.className = 'bullet-dot';

      const span = document.createElement('span');
      span.className = 'bullet-text';
      span.textContent = bullet;

      const btn = document.createElement('button');
      btn.className = 'btn-copy';
      btn.textContent = 'Copy';
      btn.addEventListener('click', () => copyText(bullet, btn, 'Copy'));

      li.append(dot, span, btn);
      list.appendChild(li);
    });

    // Outreach
    $('outreachText').textContent = data.outreachMessage || '';
    const copyAllBtn = $('copyOutreachBtn');
    copyAllBtn.onclick = () => copyText(data.outreachMessage || '', copyAllBtn, '📋 Copy All');

    // Skills Gap tags
    const gapEl = $('skillsGapTags');
    gapEl.innerHTML = '';
    (data.skillsGap || []).forEach((skill) => {
      const tag = document.createElement('span');
      tag.className = 'tag tag-red';
      tag.textContent = skill;
      gapEl.appendChild(tag);
    });

    // Keyword tags
    const kwEl = $('keywordTags');
    kwEl.innerHTML = '';
    (data.topKeywords || []).forEach((kw) => {
      const tag = document.createElement('span');
      tag.className = 'tag tag-blue';
      tag.textContent = kw;
      kwEl.appendChild(tag);
    });

    // Notion banner
    if (data.notionUrl) {
      $('notionLink').href = data.notionUrl;
      notionBanner.classList.remove('hidden');
    } else {
      notionBanner.classList.add('hidden');
    }

    showOnly(resultState);
  }

  function showError(msg) {
    $('errorMsg').textContent = msg || 'Something went wrong. Make sure the backend is running.';
    showOnly(errorState);
  }

  // ── API call ──
  async function analyze(payload) {
    showOnly(loadingState);
    notionBanner.classList.add('hidden');

    try {
      const res = await fetch(BACKEND, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url:     payload.url     || '',
          rawText: payload.rawText || '',
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
      render(data);
    } catch (err) {
      showError(err.message);
    }
  }

  // ── Event listeners ──
  $('closeBtn').addEventListener('click', () => {
    window.parent.postMessage({ type: 'CLOSE_SIDEBAR' }, '*');
  });

  $('retryBtn').addEventListener('click', () => {
    if (pagePayload) {
      analyze(pagePayload);
    } else {
      window.parent.postMessage({ type: 'RETRY' }, '*');
    }
  });

  // ── Listen for PAGE_DATA from content.js ──
  let analysisStarted = false;
  window.addEventListener('message', (event) => {
    const { type, url, rawText } = event.data || {};
    if (type === 'PAGE_DATA') {
      pagePayload = { url, rawText };
      // Only analyze once per open — ignore duplicate messages from retry interval
      if (!analysisStarted) {
        analysisStarted = true;
        analyze(pagePayload);
      }
    }
  });

  // Start in loading state
  showOnly(loadingState);
})();
